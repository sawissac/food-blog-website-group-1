# Team 1 (food-blog-website)

## Team note
- Note!: This page contain only ui design, no interaction, routing & global state storing (redux).
- Note!: We mock-data.ts to get the data.

## Used library
 - Sass
 - react-typescript
 
## How to start

`run npm install`